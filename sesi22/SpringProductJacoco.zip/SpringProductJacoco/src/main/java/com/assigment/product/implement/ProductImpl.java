package com.assigment.product.implement;

public class ProductImpl {

}
