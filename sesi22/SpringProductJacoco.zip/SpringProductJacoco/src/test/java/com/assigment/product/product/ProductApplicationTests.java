package com.assigment.product.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductApplicationTests {

	@Test
	public void contextLoads() {
	}

}
